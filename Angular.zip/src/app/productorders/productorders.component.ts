import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productorders',
  templateUrl: './productorders.component.html',
  styleUrls: ['./productorders.component.css']
})
export class ProductordersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
