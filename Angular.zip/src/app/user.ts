export class User
{
    id:number;
    user:string;
    password:string;
    constructor(id:number,user:string,password:string)
    {}
}
