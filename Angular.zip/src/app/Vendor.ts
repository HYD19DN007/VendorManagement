export class Vendor
{
    vendorId:number;
    name:string;
    dateofRegitration:Date;
    durationinDays:number;


}