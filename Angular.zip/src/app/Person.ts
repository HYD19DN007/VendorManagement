export class Person
{
    name:string;
    age:number;
    email:string;
    
    constructor(name:string,age:number,email:string)
    {}
}
